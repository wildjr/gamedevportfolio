Please play on "Ultra" graphics setting

-Controls-

Blobby
- Move: WASD
- Jump: W
- Point: Right click
- Emote: 1-5

The Hand
- Move: IJKL
- Create objects: Use the menu on the right hand side